// I commented out most of the code that is related to bluetooth this uses old protocols we are no longer using 
// the main issue I am having is once i get everything printing to the terminal the device just repeats and says no data incoming
// aka uart_poll_in = -1
// make sure to look at the prj.cfg file and the platformio.ini file
// if you have build errors related to syscall.h i would rec opening the blink example and copying this code into it and modifying the ini and prj.cfg files

#include <zephyr/types.h>
#include <stddef.h>
#include <device.h>
#include <stdlib.h>
//#include <stdio.h>
#include <sys/printk.h>
#include <sys/util.h>
#include <devicetree.h>
#include <drivers/gpio.h>
#include <drivers/uart.h>

#include <bluetooth/bluetooth.h>
#include <bluetooth/hci.h>

#define DEVICE_NAME CONFIG_BT_DEVICE_NAME
#define DEVICE_NAME_LEN (sizeof(DEVICE_NAME) - 1)
#define LED0_NODE DT_ALIAS(led0)
#define LED0	DT_GPIO_LABEL(LED0_NODE, gpios)
#define PIN	DT_GPIO_PIN(LED0_NODE, gpios)

uint8_t gpsIdentifier[] = {'!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!'};
bool test = false;

// static const struct bt_data sd[] = {
// 	BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
// };

// static void bt_ready(int err)
// {
// 	uint8_t temp[16];
	
// 	int count = 0;

// 	for (int i = 0; i < 16; i++){
// 		temp[count] = gpsIdentifier[i];
// 		count++;
// 	}

// 	char addr_s[BT_ADDR_LE_STR_LEN];
// 	struct bt_data ad[] = {
// 		BT_DATA(BT_DATA_NAME_COMPLETE, DEVICE_NAME, DEVICE_NAME_LEN),
//         BT_DATA(BT_DATA_MANUFACTURER_DATA, temp, 16),
// 	};

// 	bt_addr_le_t addr = {0};
// 	size_t count2 = 1;

// 	if (err) {
// 		printk("Bluetooth init failed (err %d)\n", err);
// 		return;
// 	}

// 	printk("Bluetooth initialized\n");
	
// 	/* Start advertising */
// 	err = bt_le_adv_start(BT_LE_ADV_NCONN_IDENTITY, ad, ARRAY_SIZE(ad),
// 			      sd, ARRAY_SIZE(sd));
// 	if (err) {
// 		printk("Advertising failed to start (err %d)\n", err);
// 		return;
// 	}

// 	bt_id_get(&addr, &count2);
// 	bt_addr_le_to_str(&addr, addr_s, sizeof(addr_s));
// }

void main(void)
{
	printk("Hello World\n");
	const struct device *uart_dev;
    uint8_t gps_data[256];
    //uint8_t rx_data;
	unsigned char rx_data;
    int gps_data_index = 0;
	int check = 0;
	
	bool flag = true;

	printk("attempting to get uart binding\n");
    uart_dev = device_get_binding(DT_LABEL(DT_NODELABEL(uart0))); // in the dts file there is a line under uart0 that hard codes the rx pin to be 8
    if (!uart_dev) {
        printk("Error: could not bind to device.\n");
        return;
    }
	printk("success\n");

	if (!device_is_ready(uart_dev)) {
        printk("UART device is not ready.\n");
        return;
    }
    printk("UART device is ready.\n");
	
    // struct uart_config uart_cfg = {
    //     .baudrate = 9600,
    //     .data_bits = UART_CFG_DATA_BITS_8,
    //     .parity = UART_CFG_PARITY_NONE,
    //     .stop_bits = UART_CFG_STOP_BITS_1,
    // };
	// I changed the framworks code library to have this set by default otherwise you will need this configuration^^^^

	printk("attempting uart config\n");
    //uart_configure(uart_dev, &uart_cfg); //This calls the device and the configuration settings and configures the uart

	printk("begin uart parsing\n");
	printk("Data: ");
    while(flag) {

		// check = uart_poll_in(uart_dev, &rx_data);
		// //printk("%d", check);
		
        // if (check == 0){
		// 	if (gps_data_index < 256 - 1) {
		// 		printk("%u", rx_data);
		// 		gps_data[gps_data_index++] = rx_data;
		// 		gpsIdentifier[gps_data_index] = rx_data;
				
		// 	} else {
		// 		// Buffer overflow, handle it accordingly
		// 		printk("GPS Data Buffer Overflow\n");
		// 		gps_data_index = 0; // Reset the index
		// 	}
				
		// 	if (gpsIdentifier[15] != '!'){
		// 		flag = false;
		// 	}
        // }

		// Wait for data to be available
        while (uart_poll_in(uart_dev, &rx_data) == -1) {
            k_sleep(K_MSEC(100)); // Wait for 100 milliseconds
        }

        // Check for end of sentence
        if (rx_data == '\n') {
            // Process the sentence
            printk("Received NMEA sentence: %s\n", gps_data);
            // Reset the sentence buffer for the next sentence
            memset(gps_data, 0, sizeof(gps_data));
            gps_data_index = 0;
        } else {
            // Add the character to the sentence buffer
            gps_data[gps_data_index++] = rx_data;
        }
    }

	// test = true;
	// int err;
	// printk("Starting Beacon Demo\n");
	// flag = true;
	// /* Initialize the Bluetooth Subsystem */
	// while(flag){
	// 	err = bt_enable(bt_ready);	
	// }
    
	// if (err) {
	// 	printk("Bluetooth init failed (err %d)\n", err);
	// }
	
}
